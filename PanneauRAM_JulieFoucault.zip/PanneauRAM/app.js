var express = require('express');
var app = express();

var http = require ('http');
var favicon = require('serve-favicon');
var bodyParser = require('body-parser');

var server = http.createServer(app);
//server.listen(8080);

var io = require('socket.io')(server);
var mysql= require('mysql');

var mqtt = require('mqtt');
var client = mqtt.connect('mqtt://172.17.50.103:1883');

app.set('view engine','ejs');
app.use(bodyParser.json());
app.use(express.static(__dirname + '/public'));
app.use(favicon(__dirname + '/public/Luma.ico'));
app.use(bodyParser.urlencoded({ extended: false }));

var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : 'root',
  database : 'bcompte'
  });
connection.connect(function (err) {
  if (err) throw err;
  console.log('Vous êtes connecté à votre DATABASE...');
  });
//Variable pour la connection de l'utilisateur
var niveau=0;
var connecte=0;
//powermeter variable
var Van = 0;
var Vbn = 0;
var Vab = 0;
var Ia = 0;
var Ib = 0;
var Kw = 0;
var Kwh = 0;
var Fp = 0;
//balance variable
var poids;
var tare;
var unite;
var aspirateur;
//panneau variable
var nivGrosB;
var nivPetitB;
var tmpGrosB;
var tmpPetitB;
var valveGrosB;
var valvePetitB;
var valveEauC;
var valveEauF;
var valveEEC;
var valveEEF;
var pompee;
//Journal
var idUser;
var identifiant;
var commande;
var descript;
client.subscribe('RAM/alarmes/etats');
io.sockets.on('connection', function(socket){
//balance et mélangeur
console.log("pika");
socket.on('Auto',function(message){
  console.log("j'ai revu auto");
  client.publish('RAM/balanceMel/cmd/mode', message);
    commande="cmd";
    insertCmd('RAM/balanceMel/cmd/mode/'+message.toString());
});
socket.on('Man',function(message){
    console.log("j'ai revu man");
    client.publish('RAM/balanceMel/cmd/mode', message);
    commande="cmd";
    insertCmd('RAM/balanceMel/cmd/mode/ '+message.toString());});
socket.on('motA',function(message){
      client.publish('RAM/balanceMel/cmd/motA', message);
      commande="cmd";
      insertCmd('RAM/balanceMel/cmd/motA/ '+message.toString());});
socket.on('motB',function(message){
      client.publish('RAM/balanceMel/cmd/motB', message);
      commande="cmd";
      insertCmd('RAM/balanceMel/cmd/motB/ '+message.toString());});
socket.on('motC',function(message){
      client.publish('RAM/balanceMel/cmd/motC', message);
      commande="cmd";
      insertCmd('RAM/balanceMel/cmd/motC/ '+message.toString());});
socket.on('recetteA',function(message){
      client.publish('RAM/balanceMel/cmd/recetteA', message);
      commande="cmd";
      insertCmd('RAM/balanceMel/cmd/recetteA/ '+message.toString());});
socket.on('recetteB',function(message){
      client.publish('RAM/balanceMel/cmd/recetteB', message);
      commande="cmd";
      insertCmd('RAM/balanceMel/cmd/recetteB/ '+message.toString());});
socket.on('recetteC',function(message){
      client.publish('RAM/balanceMel/cmd/recetteC', message);
      commande="cmd";
      insertCmd('RAM/balanceMel/cmd/recetteC/ '+message.toString());});
socket.on('recetteGo',function(message){
      client.publish('RAM/balanceMel/cmd/recetteGo', message);
      commande="cmd";
      insertCmd('RAM/balanceMel/cmd/recetteGo/ '+message.toString());});

//panneau RAM
socket.on('AutoP',function(message){
  console.log("j'ai revu auto");
  client.publish('RAM/panneau/cmd/Mode', message);
  commande="cmd";
  insertCmd('RAM/panneau/cmd/Mode/ '+message.toString());});
socket.on('ManP',function(message){
    console.log("j'ai revu manuel");
    client.publish('RAM/panneau/cmd/Mode', message);
    commande="cmd";
    insertCmd('RAM/panneau/cmd/Mode/ '+message.toString());});
socket.on('ConsNivGB',function(message){
      client.publish('RAM/panneau/cmd/ConsNivGB', message);
      commande="cmd";
      insertCmd('RAM/panneau/cmd/ConsNivGB/ '+message.toString());});
socket.on('ConsNivPB',function(message){
      client.publish('RAM/panneau/cmd/ConsNivPB', message);
      commande="cmd";
      insertCmd('RAM/panneau/cmd/ConsNivPB/ '+message.toString());});
socket.on('ConsTmpPB',function(message){
      client.publish('RAM/panneau/cmd/ConsTmpPB', message);
      commande="cmd";
      insertCmd('RAM/panneau/cmd/ConsTmpPB/ '+message.toString());});
socket.on('ValveGb',function(message){
      client.publish('RAM/panneau/cmd/ValveGB', message);
      commande="cmd";
      insertCmd('RAM/panneau/cmd/ValveGB/ '+message.toString());});
socket.on('ValvePb',function(message){
      client.publish('RAM/panneau/cmd/ValvePB', message);
      commande="cmd";
      insertCmd('RAM/panneau/cmd/ValvePB/ '+message.toString());});
socket.on('ValveEC',function(message){
      client.publish('RAM/panneau/cmd/ValveEC', message);
      commande="cmd";
      insertCmd('RAM/panneau/cmd/ValveEC/ '+message.toString());});
socket.on('ValveEF',function(message){
      client.publish('RAM/panneau/cmd/ValveEF', message);
      commande="cmd";
      insertCmd('RAM/panneau/cmd/ValveEF/ '+message.toString());});
socket.on('ValveEEC',function(message){
      client.publish('RAM/panneau/cmd/ValveEEC', message);
      commande="cmd";
      insertCmd('RAM/panneau/cmd/ValveEEC/ '+message.toString());});
socket.on('ValveEEF',function(message){
      client.publish('RAM/panneau/cmd/ValveEEF', message);
      commande="cmd";
      insertCmd('RAM/panneau/cmd/ValveEEF/ '+message.toString());});
socket.on('Pompe',function(message){
    client.publish('RAM/panneau/cmd/Pompe', message);
    commande="cmd";
    insertCmd('RAM/panneau/cmd/Pompe/ '+message.toString());});
//alarme
socket.on('NLhGb',function(message){
    client.publish('RAM/alarmes/cmd/NivLhGB', message);
    commande="cmd";
    insertCmd('RAM/alarmes/cmd/NivLhGb/ '+message);});
socket.on('NLbGb',function(message){
    client.publish('RAM/alarmes/cmd/NivLbGB', message);
    commande="cmd";
    insertCmd('RAM/alarmes/cmd/NivLbGb/ '+message.toString());});
socket.on('NLhPb',function(message){
    client.publish('RAM/alarmes/cmd/NivLhPB', message);
    commande="cmd";
    insertCmd('RAM/alarmes/cmd/NivLhPb/ '+message.toString());});
socket.on('NLbPb',function(message){
    client.publish('RAM/alarmes/cmd/NivLbPB', message);
    commande="cmd";
    insertCmd('RAM/alarmes/cmd/NivLbPb/ '+message.toString());});
socket.on('TLhPb',function(message){
    client.publish('RAM/alarmes/cmd/TempLhPB', message);
    commande="cmd";
    insertCmd('RAM/alarmes/cmd/TempLhPb/ '+message.toString());});
socket.on('TLbPb',function(message){
    client.publish('RAM/alarmes/cmd/TempLbPB', message);
    commande="cmd";
    insertCmd('RAM/alarmes/cmd/TempLbPb/ '+message.toString());});
//alarmes
socket.on('alarmes',function(message){
    commande="alarm";
    console.log("kiki");
  //  var texte= message.split('/');
    updateCmd(message);});
});

client.on('message',function(topic, message){
  var mySplit = topic.split("/");
  if(mySplit[1]=="alarmes"&&mySplit[2]=="etats"){
  commande="alarm";
console.log("j'ai recu le pikachu");
insertCmd(message.toString());
  io.sockets.emit('alarme',message.toString());}
});
function insertCmd(comd){
  var querystring = 'INSERT INTO testjournal SET LogID=NULL, Type = "'+commande+'", UserID = "'+identifiant+'", Utilisateur="'+idUser+'", Info="'+comd+'";';
  var query = connection.query(querystring, function(err, rows, fields) {
    if (!err) {
      console.log("fonction fonctionne");
  }});
}
function updateCmd(comd){
  var texte = comd.split('/');
  console.log(comd);
  console.log(texte[0]);
  console.log(texte[1]);
  var querystring = 'UPDATE testjournal SET Info="'+texte[0]+'" WHERE DoneTime IS NULL AND Info="'+texte[1]+'";';
  var query = connection.query(querystring, function(err, rows, fields) {
    if (!err) {
      console.log("fonction222 fonctionne");
  }});
}
app
.get('/', function (req, res, next) {   ///connection de l'ultilisateur
  console.log("Ma requête <accueil> est passée !");
  if(connecte ==0){
  res.render('accueil');}
  else{
    res.render('principale');
  }

  })

.post('/', function(req,res,next){   ///POST connection de l'ultilisateur
    //console.log(req.body);
    var querystring =  'SELECT * FROM tuser WHERE Utilisateur ="'+req.body.id+'" AND MotDePasse ="'+req.body.mdpasse+'";';
    var query = connection.query(querystring, function(err, rows, fields) {
      if (!err) {
        console.log("Connection réussi !");
        connecte =1;
        if(rows[0]){
          niveau =rows[0].Niveau;//mettre le niveau
          console.log(niveau);
          identifiant=rows[0].Id;//mettre le id
          console.log(identifiant);
          idUser=rows[0].Utilisateur;//mettre le nom d'utilisateur
        res.render('principale');
      }
      else {
        res.render('error',{ message:"Votre mots de passe ou votre identifiant est incorrect"});
        niveau =0;
        connecte =0;
      }
    }

  });

})
.get('/propos', function (req, res, next) {   ///Auteur de création
  console.log("Ma requête <a propos> est passée !");
  if(connecte ==0){
  res.render('accueil');}
  else{
    res.render('propos');
  }

})
.get('/powermeter', function (req, res, next) {   ///Auteur de création
  console.log("Ma requête <powermeter> est passée !");

  client.subscribe('RAM/powermeter/etats/#');
  client.on('message',function(topic, message){
    if(topic.indexOf("RAM") !== 1){
      var mySplit = topic.split("/");///mySplit est un tableau information {RAM, powermeter,blablabla}

      console.log(message.toString());
      //var numModule = mySplit[mySplit.length-1];//on a notre numéro du module
      if(mySplit[3]== "Van"){
       Van =message.toString();
       io.sockets.emit('van',Van);
      }
      else if(mySplit[3]== "Vbn"){
        Vbn=message.toString();
        io.sockets.emit('vbn',Vbn);
      }
      else if(mySplit[3]== "Vab"){
       Vab =message.toString();
       io.sockets.emit('vab',Vab);
      }
      else if(mySplit[3]== "Ia"){
       Ia =message.toString();
       io.sockets.emit('ia',Ia);
      }
      else if(mySplit[3]== "Ib"){
       Ib =message.toString();
       io.sockets.emit('ib',Ib);
      }
      else if(mySplit[3]== "KW"){
       Kw =message.toString();
       io.sockets.emit('kw',Kw);
      }
      else if(mySplit[3]== "KWh"){
       Kwh =message.toString();
       io.sockets.emit('kwh',Kwh);
      }
      else if(mySplit[3]== "FP"){
       Fp =message.toString();
       io.sockets.emit('fp',Fp);
      }


    }
  })
  if(connecte){
  res.render('powermeter');
  }
  else{
      res.render('error',{ message:"Vous n'avez pas accès à cette page. Désoler."});
  }

})
.get('/balance',function (req,res,next){
  console.log("Ma requête <Balance/mélangeur> est passée !");
  client.publish('RAM/balanceMel/cmd/mode', "auto");
  commande="cmd";
  insertCmd('RAM/balanceMel/cmd/mode/auto');
  client.subscribe('RAM/balanceMel/etats/#');
  client.subscribe('RAM/shopvac/#');
  client.on('message',function(topic, message){
    if(topic.indexOf("RAM") !== 1){
      var mySplit = topic.split("/");

      if(mySplit[3]== "poids"){
       poids =message.toString();
       io.sockets.emit('pds',poids);
      }
      else if(mySplit[3]== "tare"){
        tare =message.toString();
        io.sockets.emit('tr',tare);
      }
      else if(mySplit[3]== "unite"){
       unite =message.toString();
       io.sockets.emit('unit',unite);
     }if(mySplit[1]== "shopvac"){
        aspirateur =message.toString();
        io.sockets.emit('aspira',aspirateur);
      }
    }})
  if(connecte){
  res.render('balance',{valide:niveau});}//enlever les commandes dans les recettes pour l'inviter
  else{
    res.render('error',{ message:"Vous n'avez pas accès à cette page. Désoler."});
  }
})
.get('/panneauRam',function(req,res,next){
  console.log("Ma requête <PanneauRam> est passée !");
  client.publish('RAM/panneau/cmd/Mode', "auto");
  commande="cmd";
  insertCmd('RAM/panneau/cmd/Mode/auto');
  client.subscribe('RAM/panneau/etats/#');
  client.on('message',function(topic, message){
    if(topic.indexOf("RAM") !== 1){
      var mySplit = topic.split("/");///mySplit est un tableau information {RAM, powermeter,blablabla}

      if(mySplit[3]== "NivGB"){
       nivGrosB =message.toString();
       io.sockets.emit('NGB',nivGrosB);
      }
      else if(mySplit[3]== "NivPB"){
        nivPetitB =message.toString();
        io.sockets.emit('NPB',nivPetitB);
      }
      else if(mySplit[3]== "TmpGB"){
       tmpGrosB =message.toString();
       io.sockets.emit('TGB',tmpGrosB);
      }
      else if(mySplit[3]== "TmpPB"){
       tmpPetitB =message.toString();
       io.sockets.emit('TPB',tmpPetitB);
      }
      else if(mySplit[3]== "ValveGB"){
       valveGrosB =message.toString();
       io.sockets.emit('VGB',valveGrosB);
      }
      else if(mySplit[3]== "ValvePB"){
       valvePetitB =message.toString();
       io.sockets.emit('VPB',valvePetitB);
      }
      else if(mySplit[3]== "ValveEC"){
       valveEauC =message.toString();
       io.sockets.emit('VEC',valveEauC);
      }
      else if(mySplit[3]== "ValveEF"){
       valveEauF =message.toString();
       io.sockets.emit('VEF',valveEauF);
      }
      else if(mySplit[3]== "ValveEEC"){
       valveEEC =message.toString();
       io.sockets.emit('VEEC',valveEEC);
      }
      else if(mySplit[3]== "ValveEEF"){
       valveEEF =message.toString();
       io.sockets.emit('VEEF',valveEEF);
      }
      else if(mySplit[3]== "Pompe"){
       pompee =message.toString();
       io.sockets.emit('Pomp',pompee);
      }
    }})
  if(connecte){//enlever les commandes du panneau pour l'invité
  res.render('panneauRam',{valide:niveau});}
  else{
    res.render('error',{ message:"Vous n'avez pas accès à cette page. Désoler."});
  }
})
.get('/journal',function(req,res,next){
  if(niveau>2 &&connecte){
    var querystring ='SELECT * FROM testjournal';
    var  query = connection.query(querystring, function(err, rows, fields) {
        if (!err) {
          console.log("Ma requête <journal> est passée !");
            res.render('journal',{colone:rows, ligne:fields});
            }});
  }
  else
  {
      res.render('error',{ message:"Vous n'avez pas accès à cette page. Désoler."});
  }
})
.post('/journal',function(req,res,next){
  var querystring = 'SELECT * FROM testjournal WHERE Utilisateur="'+req.body.us+'";';
  var query = connection.query(querystring, function(err, rows, fields) {
    if (!err) {
      console.log("TRIER");
      res.render('journal',{colone:rows, ligne:fields});
  }});
})
.get('/gestion', function(req,res,next){  ///gestion des compte par l'Admin seulement
  if(niveau >2 && connecte)
  {
    var querystring ='SELECT * FROM tuser';
    var  query = connection.query(querystring, function(err, rows, fields) {
        if (!err) {
          console.log("Ma requête <gestion> est passée !");
            res.render('gestion',{colone:rows, ligne:fields});
            }});
  }
  else
  {
      res.render('error',{ message:"Vous n'avez pas accès à cette page. Désoler."});
    }
  })
.post('/gestion',function(req,res,next){     ///Post gestion des compte par l'Admin
  if(req.body.action == 1){
    var querystring = 'INSERT INTO tuser SET Id=NULL, Utilisateur ="'+req.body.nomId+'", MotDePasse ="'+req.body.motDP+'", Niveau = "'+req.body.niveau+'";';
    var query = connection.query(querystring, function(err, rows, fields) {
      if (!err) {
        console.log("AJOUTE");
    }});
    querystring ='SELECT * FROM tuser';
    query = connection.query(querystring, function(err, rows, fields) {
        if (!err) {
          console.log("Ma requête <gestion> est passée !");
            res.render('gestion',{colone:rows, ligne:fields});
          }});
  }
  else if(req.body.action == 2){
    var querystring = 'DELETE FROM tuser WHERE Utilisateur ="'+req.body.nomId+'" AND MotDePasse="'+req.body.motDP+'";';
    var query = connection.query(querystring, function(err, rows, fields) {
      if (!err) {
        console.log("DELETE");
    }});
    querystring ='SELECT * FROM tuser';
    query = connection.query(querystring, function(err, rows, fields) {
        if (!err) {
          console.log("Ma requête <gestion> est passée !");
            res.render('gestion',{colone:rows, ligne:fields});
          }});
  }
  else if(req.body.action == 3){
    var querystring = 'UPDATE tuser SET Utilisateur ="'+req.body.newId+'", MotDePasse ="'+req.body.newMDP+'", Niveau ="'+req.body.newNiv+'" WHERE Utilisateur="'+req.body.nomId+'" AND MotDePasse ="'+req.body.motDP+'";';
    var query = connection.query(querystring, function(err, rows, fields) {
      if (!err) {
        console.log("MODIFIE");
    }});
    querystring ='SELECT * FROM tuser';
    query = connection.query(querystring, function(err, rows, fields) {
        if (!err) {
          console.log("Ma requête <gestion> est passée !");
            res.render('gestion',{colone:rows, ligne:fields});
          }});
  }

})
.get('/alarme',function(req,res,next){
  if(connecte && niveau >1){
  res.render('alarme');
  }
  else {

        res.render('error',{ message:"Vous n'avez pas accès à cette page. Désoler."});

  }
})
.get('/principale',function(req,res,next){
  if(connecte){

          console.log("Ma requête <principale> est passée !");
            res.render('principale');
  }
  else {

        res.render('error',{ message:"Vous n'avez pas accès à cette page. Désoler."});

  }

}) ///Page principale
.get('/camera',function(req,res,next){
  if(connecte && niveau >0){
    res.render('camera');
  }
  else {
      res.render('error',{ message:"Vous n'avez pas accès à cette page. Désoler."});
  }
})
.get('/deconnection', function(req,res,next){
  connecte =0;
  res.render('deconnection');
})
.use(function (req, res, next) {
    server.on('request', function (req, res) {
    res.writeHead(404);});
    console.log('TimePika:', Date.now());
  next();
});
server.listen(8080);
